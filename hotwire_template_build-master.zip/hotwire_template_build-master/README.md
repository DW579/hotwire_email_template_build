# hotwire_template_build
Build and download the most up-to-date Hotwire template library as one html file
